<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class haha extends Controller
{
    //
    public function getData(){
        $temp = array();
        $temp["name"] = "yahya";
        $temp["age"] = 19;

        return $temp;
    }
}
