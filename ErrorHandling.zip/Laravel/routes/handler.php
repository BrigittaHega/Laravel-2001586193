<?php

namespace App\Exception;

use Exception;
use Illuminate\Auth\AuthenticationException;

?>