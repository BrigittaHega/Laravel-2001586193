<?php

namespace App\Http\Controllers;

use Illuminate\Http\Requests;

use App\User;
use App\Http\Requests;

class teamController extends Controller
{
	public function_construct()
	{
		$this = middleware('auth');

		return response()->json($users);
	}

		@return

	public function index()
	{
		return view('home');
	}

	public function pagenotfound()
	{
		return view('error.404');
	}
}