<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
* 
*/
class Member extends Model
{
	protected $timestamps = 'false';
	protected $table= "members";
	protected $fillable = ['username','email','password'];
	protected $guarded = [];

	//public function team()
	//{
	//	return $this->belongsTo('App\Models\Team', 'team_id');
	//}
}